<html>
    <body>
        Area selected is <?php echo $_POST["area"]; ?><br>
        Food type is : <?php echo $_POST["type"]; ?><br>
        Cuisine is : <?php echo $_POST["cuisine"]; ?>
    </body>
</html>
